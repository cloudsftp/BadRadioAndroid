package com.badradio.nz;


public class Config {

    public static final int DEFAULT_VOLUME = 11;


}