package com.badradio.nz.metadata;

public interface ShoutcastMetadataListener {
    void onMetadataReceived(Metadata data);
}